#include "hashchain.cc"
#ifdef NOYIELD
#error NOYIELD must not be defined for the actual submission
#endif

int main() {
  return 0;
}
