/*
 * exec1.c
 */

#include "syscall.h"

main()
{
 Exit(1);
}
