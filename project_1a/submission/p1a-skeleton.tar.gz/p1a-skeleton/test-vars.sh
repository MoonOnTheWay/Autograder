#set vars used by make test-* and make test here
numthreads=100
numkeys=500
numiter=2
